쇼츠 브금 박스 — ⚡ 반전·드라마틱·호러

CC0 1.0 (퍼블릭 도메인). 상업적 이용·수익 창출 가능, 출처 표기 불필요.
원본: FreePD.com 아카이브 https://archive.org/details/freepd

- Dreams of Vain — Rafael Krux (96초)
- Hidden Truth — Rafael Krux (98초)
- Black Knight — Rafael Krux (142초)
- Big Eyes — Rafael Krux (149초)