쇼츠 브금 박스 — ☕ 일상·힐링·동물

CC0 1.0 (퍼블릭 도메인). 상업적 이용·수익 창출 가능, 출처 표기 불필요.
원본: FreePD.com 아카이브 https://archive.org/details/freepd

- River Meditation — Jason Shaw (167초)
- Goldcrest — James Anderson (142초)
- Amazing Grace — Kevin MacLeod (114초)
- Neptunian Princess — Bryan Teoh (125초)