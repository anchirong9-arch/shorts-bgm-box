쇼츠 브금 박스 — 🛒 신나는·쇼핑·리뷰

CC0 1.0 (퍼블릭 도메인). 상업적 이용·수익 창출 가능, 출처 표기 불필요.
원본: FreePD.com 아카이브 https://archive.org/details/freepd

- Stereotype News — Rafael Krux (65초)
- Inventing Flight — Bryan Teoh (141초)
- Celebration — Alexander Nakarada (143초)
- Energizing — Kevin MacLeod (133초)